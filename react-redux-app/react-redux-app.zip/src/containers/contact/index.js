import React from 'react';
//require( 'datatables.net-dt' )();ss
const Contact = () => (
  <div>
    <h1>contact Page</h1>
    <p>Did you get here via Redux?</p>
  </div>
);

export default Contact;
